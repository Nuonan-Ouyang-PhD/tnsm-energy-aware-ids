OVERLEAF PROJECT

Upload TNSM_Overleaf.zip as a new Overleaf project.
Compiler: pdfLaTeX. Main document: main.tex.

To compile the other documents, change the main document to:
supplement.tex
Response_to_Reviewers.tex
Cover_Letter.tex

The manuscript sources, figure files, tables and bibliography are unchanged.
