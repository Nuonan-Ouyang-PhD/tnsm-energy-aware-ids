"""Review-only adapter. NOT Darwin validation and NOT a production fallback.
Uses the real Linux renameat2(RENAME_NOREPLACE) only at the foreign-function boundary.
All archive/authorization/contract/source/serialization code remains unmodified.
"""
import ctypes, sys
REAL_CDLL = ctypes.CDLL
LIBC = REAL_CDLL(None, use_errno=True)
RENAMEAT2 = LIBC.renameat2
RENAMEAT2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
RENAMEAT2.restype = ctypes.c_int
class RenameFacade:
    argtypes = None
    restype = None
    def __call__(self, oldfd, oldname, newfd, newname, flags):
        assert flags == 4, 'expected Darwin RENAME_EXCL request'
        return RENAMEAT2(oldfd, oldname, newfd, newname, 1)
class LibraryFacade:
    def __init__(self): self.renameatx_np = RenameFacade()
class Proxy:
    def __init__(self, original, **overrides): self.original=original;self.overrides=overrides
    def __getattr__(self, name):
        if name in self.overrides: return self.overrides[name]
        return getattr(self.original,name)
def install(module):
    module.sys=Proxy(sys,platform='darwin')
    module.ctypes=Proxy(ctypes,CDLL=lambda *a,**k: LibraryFacade())
