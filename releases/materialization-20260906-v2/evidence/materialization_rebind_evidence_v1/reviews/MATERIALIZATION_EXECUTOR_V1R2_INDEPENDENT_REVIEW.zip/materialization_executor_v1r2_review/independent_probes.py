"""Read-only audit inputs; all execution uses invented temporary fixture data."""
import sys,os,json,tempfile,hashlib,ctypes,stat
from pathlib import Path
from unittest.mock import patch
A=Path(__file__).resolve().parent;R=A/'v1r2/materialization_executor_evidence_v1r2'
sys.dont_write_bytecode=True;os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.path.insert(0,str(R))
from tests import test_materializer_synthetic as t
from linux_noreplace_adapter import install
m=t.materializer
helper=t.MaterializerSyntheticTests();out={}
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(p):return {q.relative_to(p).as_posix():h(q) for q in p.rglob('*') if q.is_file()}
# E01: mutate each of the ten bound local files independently; unchanged evidence ZIP/authorization.
mutations=[]
with tempfile.TemporaryDirectory(prefix='f23-e01-') as tmp:
 c=t.SyntheticCase(Path(tmp));ev=helper.prepare_cli_authorization(c)
 originals={p:(c.package/p).read_bytes() for p in c.contract['runtime_evidence_binding']['required_local_files']}
 # SyntheticCase copies the source paths into its contract correctly.
 assert len(originals)==10
 for rel,data in originals.items():
  p=c.package/rel;p.write_bytes(data+(b'\n# independent inert comment\n' if p.suffix=='.py' else b'\n'))
  root_trap=c.base/'MUST_NOT_BE_ACCESSED'
  r=helper.run_cli(c,ev,{k:root_trap for k in c.source_roots})
  row={'file':rel,'exit_code':r.returncode,'stderr':r.stderr,'expected_binding_rejection':r.returncode==2 and 'differs from approved evidence' in r.stderr,'no_output_or_staging':not c.output.exists() and not c.staging.exists()}
  assert row['expected_binding_rejection'] and row['no_output_or_staging'],row
  mutations.append(row);p.write_bytes(data)
out['E01_ten_independent_bound_file_mutations']=mutations
# E02 + E03: full synthetic preflight counts all 8 entries, exactly 7 are renderable.
# Render to actual files and replay each shard with all write opens prohibited.
with tempfile.TemporaryDirectory(prefix='f23-replay-') as tmp:
 c=t.SyntheticCase(Path(tmp));docs=m.validate_bound_metadata(c.contract,c.package)
 scans=m.preflight_sources(c.contract,docs,c.source_roots)
 seen=sum(map(len,scans.values()));assert seen==8
 assert any(x.relative_path=='demonstrate_structure.csv' and x.row_count==0 for x in scans['n_baiot'])
 out['E03_synthetic_preflight']={'all_input_entries_scanned':seen,'structure_scanned_zero_row':True,'registered_non_lf_exceptions':3}
 look=m.ontology_lookups(docs['label_ontology']);exc=m.expected_exception_index(docs['cic_quality_exceptions']);rep=[]
 target=c.base/'review_render';target.mkdir()
 for ds in c.contract['ordering']['dataset_order']:
  for i,it in enumerate(m.data_source_items(ds,docs[ds])):
   fp=target/(ds+'_'+str(i)+'_features.csv');lp=target/(ds+'_'+str(i)+'_labels.csv')
   first=m.render_shard(c.contract,ds,it,c.source_roots[ds]/it['relative_path'],exc if ds=='ciciot2023' else {},look,fp,lp,m.ByteBudget(10**7))
   before=snapshot(c.base);orig_open=Path.open;opened=[]
   def readonly_open(path,mode='r',*a,**k):
    assert not any(x in mode for x in 'wax+'),f'replay attempted writing {path}'
    opened.append(str(path));return orig_open(path,mode,*a,**k)
   with patch.object(Path,'open',readonly_open):
    second=m.replay_shard(c.contract,ds,it,c.source_roots[ds]/it['relative_path'],exc if ds=='ciciot2023' else {},look)
   same=first==second;unchanged=snapshot(c.base)==before
   assert same and unchanged
   rep.append({'dataset':ds,'source':it['relative_path'],'same_rendered_record':same,'disk_files_unchanged':unchanged,'read_opens':opened})
 out['E02_seven_direct_read_only_replays']=rep
# E04 unsupported-platform path uses the actual, unmodified Linux platform guard.
with tempfile.TemporaryDirectory(prefix='f23-platform-') as tmp:
 base=Path(tmp);lease=m.create_staging_lease(base/'final',base/'.final.staging');(lease.staging_path/'keep').write_text('keep')
 try:
  try:m.atomic_publish_noreplace(lease,base/'final');raise AssertionError('native Linux must refuse')
  except m.MaterializationError as e:
   assert 'unsupported on this platform' in str(e)
   out['E04_native_unsupported_platform']={'refused':True,'message':str(e),'staging_retained':(lease.staging_path/'keep').read_text()=='keep','no_final':not (base/'final').exists()}
 finally:lease.close()
# Native Darwin API not available; adapter tests the call signature/flag and real Linux exclusive rename.
install(m)
late=[]
for typ in ('empty_dir','nonempty_dir','file','symlink'):
 with tempfile.TemporaryDirectory(prefix='f23-noreplace-') as tmp:
  b=Path(tmp);dst=b/'final';st=b/'.final.staging';lease=m.create_staging_lease(dst,st);(st/'verified').write_text('source')
  if typ=='empty_dir':dst.mkdir()
  elif typ=='nonempty_dir':dst.mkdir();(dst/'foreign').write_text('keep')
  elif typ=='file':dst.write_text('keep')
  else:(b/'elsewhere').write_text('keep');dst.symlink_to(b/'elsewhere')
  orig=dst.lstat();before=snapshot(b)
  try:
   try:m.atomic_publish_noreplace(lease,dst);raise AssertionError('must reject existing destination')
   except m.MaterializationError as e:
    now=dst.lstat();ok=(orig.st_ino,orig.st_dev,orig.st_mode)==(now.st_ino,now.st_dev,now.st_mode)
    assert ok and before==snapshot(b) and 'final output appeared' in str(e)
    late.append({'type':typ,'refused':True,'entry_identity_unchanged':ok,'tree_bytes_unchanged':True,'not_native_darwin':True})
  finally:lease.close()
out['E04_adapter_late_entries']=late
# Frozen real inventory metadata only, never CSVs: identity and normative feature output unchanged.
c=json.loads((R/'contract/materialization_contract_v1r2.json').read_bytes())
out['frozen_expected_counts']=c['expected_real_output'];out['runtime_binding_count']=len(c['runtime_evidence_binding']['required_local_files'])
inputs={k:json.loads((R/v['file']).read_bytes()) for k,v in c['input_binding']['inventories'].items()}
out['inventory_census']={'files':sum(len(x['files']) for x in inputs.values()),'bytes':sum(sum(i['bytes'] for i in x['files']) for x in inputs.values()),'rows':sum(sum(i['row_count'] for i in x['files']) for x in inputs.values())}
assert out['inventory_census']=={'files':400,'bytes':17114499704,'rows':54050349}
# Save all source files used as the basis of conclusions with line-numbered excerpts.
ranges={'scripts/materialize_dataset_native_v1r2.py':[(423,546),(681,813),(981,990),(994,1084),(1250,1324)],'contract/materialization_contract_v1r2.json':[(1,100)]}
lines=[]
for rel,rr in ranges.items():
 text=(R/rel).read_text().splitlines()
 for lo,hi in rr:
  lines.append('\n### '+rel+f' L{lo}-L{hi}')
  lines.extend(f'L{i}: {text[i-1]}' for i in range(lo,min(hi,len(text))+1))
(A/'source_excerpts.txt').write_text('\n'.join(lines)+'\n')
(A/'independent_probe_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('E01 bound local files:',len(mutations),'refused; E02 direct read-only replay:',len(rep),'passed; E03 all 8 fixtures preflighted; E04 native fail-closed and 4 adapter exclusive-rename refusal types passed')
