from pathlib import Path
import json,hashlib,zipfile,stat,difflib,platform,datetime
A=Path(__file__).resolve().parent;R=A/'v1r2/materialization_executor_evidence_v1r2';V=A/'v1/materialization_executor_evidence_v1'
def sh(data):return hashlib.sha256(data).hexdigest()
def snap(root):return {q.relative_to(root).as_posix():{'sha256':sh(q.read_bytes()) if q.is_file() else None,'mode':oct(stat.S_IMODE(q.stat().st_mode))} for q in sorted(root.rglob('*'))}
base=json.loads((A/'source_snapshot_before.json').read_text());unchanged=base==snap(R);assert unchanged
with zipfile.ZipFile('/mnt/data/FEATURE_PROTOCOL_FREEZE_EVIDENCE_V1.zip') as z:
 frozen={}
 for file in ('feature_policy.json','label_ontology.json'):
  matches=[n for n in z.namelist() if n.endswith('/config/'+file)]
  assert len(matches)==1
  b=z.read(matches[0]);now=(R/'inputs/protocol'/file).read_bytes();assert b==now
  frozen[file]={'same_as_accepted_24_zip':True,'sha256':sh(now)}
# Untouched scientific output components and fixture changes.
old=json.loads((V/'contract/materialization_contract_v1r1.json').read_bytes());new=json.loads((R/'contract/materialization_contract_v1r2.json').read_bytes())
scientific_keys=['feature_contract','label_sidecar','expected_real_output','input_binding','baseline_request']
scientific_unchanged={k:old[k]==new[k] for k in scientific_keys};assert all(scientific_unchanged.values())
fixture_diffs={}
for i in (7,8,9):
 rel=f'tests/fixtures/source/ciciot2023/CSV/DoS-UDP_Flood/DoS-UDP_Flood{i}.pcap.csv'
 before=(V/rel).read_bytes();after=(R/rel).read_bytes();assert before==after+b'\n'
 fixture_diffs[rel]={'only_terminal_LF_removed':True,'old_bytes':len(before),'new_bytes':len(after)}
info={'review_scope':'Independent static and synthetic review only; no raw datasets, live Mac, target volume or git object inspection','platform':platform.platform(),'input_tree_unchanged_through_end':unchanged,'frozen_config_comparison':frozen,'scientific_contract_components_unchanged':scientific_unchanged,'synthetic_fixture_changes':fixture_diffs,'decision':{'E01':'closed at implementation and synthetic level','E02':'closed at implementation and synthetic level','E03':'closed at implementation and synthetic level; 400 real files NOT scanned','E04_cleanup':'closed; no automatic recursive delete','E04_publication':'source, unsupported-platform refusal and Linux exclusive-rename adapter accepted; native Darwin/new-volume test remains a deployment prerequisite','additional_source_repair_required':False,'artifact_accepted_as':'output-volume rebind implementation baseline','authorization_granted':False,'materialization_authorized':False,'splitting_authorized':False,'training_authorized':False,'allowed_next_step':'volume metadata discovery; tiny non-dataset capability probes on a newly confirmed volume; prepare reviewed output/staging rebind; do not run real datasets'}}
(A/'review_decision.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
# Renamed script / contract diffs are for review only.
for oldrel,newrel,label in [('scripts/materialize_dataset_native_v1.py','scripts/materialize_dataset_native_v1r2.py','executor'),('contract/materialization_contract_v1r1.json','contract/materialization_contract_v1r2.json','contract')]:
 d=''.join(difflib.unified_diff((V/oldrel).read_text().splitlines(True),(R/newrel).read_text().splitlines(True),fromfile='V1/'+oldrel,tofile='V1R2/'+newrel))
 (A/(label+'_diff.patch')).write_text(d)
report='''# 物化执行器 V1R2 独立复验

## 裁定

E01–E04 在本轮实现及合成验证范围内通过，接受 V1R2 作为下一阶段输出卷重绑定的实现基线。
没有新增代码阻断项，不要求仅为本审阅环境增加 Linux fallback 或提交新的代码修复版本。
原生 Darwin/实际新卷 RENAME_EXCL 能力仍是部署前置条件。本报告不授予真实数据物化、划分或训练权限。

## 附件身份

- ZIP: MATERIALIZATION_EXECUTOR_EVIDENCE_V1R2.zip
- SHA-256: 760163ee757620422d0eb013b8c7574015a01b40326021c21c891a097dfd29df
- 大小: 134,672 B
- 71 条目: 47 文件(含 MANIFEST) + 24 目录
- 模式: 47×644 + 24×755
- MANIFEST: 46/46，完整覆盖，自排除，CRC/路径/重复/链接/杂项通过
- MANIFEST SHA: ef9aa5b5a892d44a5d82b24e2cb7e048573855384ba9b5ae731f0f01e8d1e738
- contract SHA: 8ea75744ae3c96bf8a623d8a1a6aed992d10b149cdb8a96d4280e70134d68105
- executor SHA: ac9992005047bda7431abccafe8698d5b3b890efbf218605841730a5613b1c2c

## 测试口径

本环境为 Linux，不是用户 Mac。未经修改原样运行 37 项时，6 个方法受到 Darwin 专用系统调用限制，unittest 报告 failures=5、errors=4：其中一个方法包含 4 个目的路径类型的失败子测试。其余 31 个方法单独以原实现重跑 31/31 通过；无跳过。

独立的审阅适配器只在外部函数边界把 renameatx_np(flags=4) 转发到 Linux renameat2(flags=1)，执行同一原发布函数；没有改写合同、执行源码、配置、授权绑定或输入工件。包含正向 CLI 子进程的全套 37/37 在此模式下通过。这不是 Darwin 或新盘的实测结果，不属于生产回退实现。

包内语义/哈希验证器在原样环境重跑 187/187 通过。原包 reports/ 下的 37/37 是交付日志；独立原生 Mac 37/37 未复现。

## E01–E04 独立检查

E01: 对实际合同、执行器及八个运行元数据文件逐一进行字节漂移测试。固定合成获准 ZIP 和测试授权记录不变；10/10 CLI 拒绝，未创建输出/staging。语义相同但空白不同的 JSON 同样被拒绝。运行元数据不等于真实 CSV，本次没有访问真实源数据。

E02: 在 7 个合成源分片上分别调用 render/replay，重放阶段禁止任何写模式 Path.open。7/7 结果、哈希和字节数一致，目录文件哈希不变。包内大字段空间模型测试也在系统调用适配模式下通过，无 .replay-* 文件。不是对真实17GB数据的性能或空间实测。

E03: 全部 8 个合成 inventory 项均通过同一预检，包括唯一零行结构文件；渲染项为7。追加结构数据且不更新身份时拒绝，更新合成清单后仍因非零行拒绝。普通无LF末行、未登记异常、带LF的新登记异常均拒绝；仅精确登记的3条无LF尾行通过。真实400项仅从元数据求和核对，未扫描CSV。

E04: 原实现在Linux上原生拒绝不支持的发布，保留staging，未产生final。在审阅适配模式下，晚到空目录、非空目录、普通文件和符号链接4/4拒绝，身份与内容不变。替代staging与移走的原staging均保留，不再执行自动rmtree。原生Darwin系统调用及目标外置卷行为需要下一阶段现场证据。

## 不变性

两个冻结config与本地实际保存的#24冻结ZIP逐字节一致。八个既有运行元数据文件、14个静态期望输出均与V1相同。特征合同、标签旁表、预期行数、输入绑定及原申请绑定均未变化。三个合成CIC异常源文件只去掉末尾LF，与已登记无LF的语义一致；不是真实CSV改动。

按未归一化文件名比较：新增7、删除3(旧版本文件名由新版本替代)、共有修改10、相同29；详见basic_review.json。所有本轮审阅及测试结束后原解包树内容和权限与初始快照相同。

## 下一阶段

允许准备新卷只读元数据和输出路径重绑定。容量及设备/卷标识、文件系统、实际挂载点、可写性、final/staging同父目录与同文件系统应真实记录，不猜路径、不沿用旧可用空间。最低空间仍是合同中的26,745,491,380B，最终输出硬上限25,671,749,556B。

RENAME_EXCL能力测试会写少量人工哨兵文件，故必须标注为非数据临时探测，不宣称整个步骤纯只读；不碰正式output/staging或真实CSV。成功发布、四类已存在目标拒绝、失败保留、功能不支持时无回退均应在真实卷记录。此步骤不授权擦盘、格式化、删除原资料、物化、划分、训练。

未验证用户Git提交8024d715…、工作树、Mac当前磁盘状态，也未读取/哈希真实CSV。所有授权记录和新增输出均为审阅环境人工样例，不能在生产使用。
'''
(A/'REVIEW.md').write_text(report)
# Summarize only observed external documentation; source claims derive from code and logs.
(A/'external_reference_note.md').write_text('Apple APFS Tools and APIs documents the renameatx_np signature. API documentation is not evidence that the user target volume supports it.\nhttps://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/APFS_Guide/ToolsandAPIs/ToolsandAPIs.html\n')
# Bundle review-generated records, scripts, and logs, never the extracted evidence trees.
files=sorted([p for p in A.iterdir() if p.is_file()],key=lambda p:p.name.encode())
manifest=''.join(f'{sh(p.read_bytes())}  {p.name}\n' for p in files)
(A/'REVIEW_MANIFEST_SHA256.txt').write_text(manifest)
files.append(A/'REVIEW_MANIFEST_SHA256.txt')
out=Path('/mnt/data/MATERIALIZATION_EXECUTOR_V1R2_INDEPENDENT_REVIEW.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  info=zipfile.ZipInfo('materialization_executor_v1r2_review/'+p.name)
  info.create_system=3;info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,p.read_bytes())
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'review_zip':str(out),'sha256':sh(out.read_bytes()),'size':out.stat().st_size,'files':len(files),'source_unchanged':unchanged,'frozen_comparison':frozen},indent=2))
