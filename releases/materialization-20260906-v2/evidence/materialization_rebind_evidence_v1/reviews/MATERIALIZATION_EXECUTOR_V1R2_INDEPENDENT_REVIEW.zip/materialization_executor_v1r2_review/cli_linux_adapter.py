"""Review-only launcher, not an execution authorization or a Darwin environment."""
import importlib.util,sys
from pathlib import Path
from linux_noreplace_adapter import install
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('review_cli_materializer',p)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
install(m)
sys.exit(m.main(sys.argv[2:]))
