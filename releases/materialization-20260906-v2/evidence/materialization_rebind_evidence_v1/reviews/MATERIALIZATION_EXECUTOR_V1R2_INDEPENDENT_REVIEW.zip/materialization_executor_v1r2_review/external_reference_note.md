Apple APFS Tools and APIs documents the renameatx_np signature. API documentation is not evidence that the user target volume supports it.
https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/APFS_Guide/ToolsandAPIs/ToolsandAPIs.html
