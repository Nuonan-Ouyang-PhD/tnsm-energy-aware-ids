from pathlib import Path
import hashlib,json,stat,subprocess,os,sys,difflib
A=Path(__file__).resolve().parent
R=A/'v1r2/materialization_executor_evidence_v1r2'
V=A/'v1/materialization_executor_evidence_v1'
def sha(b): return hashlib.sha256(b).hexdigest()
def snap(p):
 return {q.relative_to(p).as_posix():{'sha256':sha(q.read_bytes()) if q.is_file() else None,'mode':oct(stat.S_IMODE(q.stat().st_mode))} for q in sorted(p.rglob('*'))}
s=snap(R)
manifest=R/'MANIFEST_SHA256.txt'
entries={}
for line in manifest.read_text().splitlines():
 h,n=line.split('  ',1); assert n not in entries; assert sha((R/n).read_bytes())==h,n;entries[n]=h
assert set(entries)=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p!=manifest}
res={'manifest_count':len(entries),'manifest_sha256':sha(manifest.read_bytes()),'runtime_hashes':{p:sha((R/p).read_bytes()) for p in ['contract/materialization_contract_v1r2.json','scripts/materialize_dataset_native_v1r2.py','inputs/protocol/feature_policy.json','inputs/protocol/label_ontology.json']}}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
for name,cmd in [('manifest',['sha256sum','-c','MANIFEST_SHA256.txt']),('verifier',[sys.executable,'-B','scripts/verify_executor_evidence_v1r2.py','--root','.']),('unittest_native_linux',[sys.executable,'-B','-m','unittest','-v','tests/test_materializer_synthetic.py','tests/test_executor_evidence.py'])]:
 p=subprocess.run(cmd,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
 (A/(name+'.log')).write_text(p.stdout);res[name]={'exit_code':p.returncode,'command':cmd,'output_tail':p.stdout[-2500:]}
 print(name,p.returncode,p.stdout[-1600:])
res['input_snapshot_unchanged']=s==snap(R)
(A/'source_snapshot_before.json').write_text(json.dumps(s,indent=2)+'\n')
old={p.relative_to(V).as_posix():p for p in V.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.txt'}
new={p.relative_to(R).as_posix():p for p in R.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.txt'}
added=sorted(new.keys()-old.keys());removed=sorted(old.keys()-new.keys());changed=sorted(k for k in old.keys()&new.keys() if old[k].read_bytes()!=new[k].read_bytes());same=sorted((old.keys()&new.keys())-set(changed))
res['diff']={'added':added,'removed':removed,'changed':changed,'same':same,'counts':{'added':len(added),'removed':len(removed),'changed':len(changed),'same':len(same)}}
res['frozen_inputs_same']={k:old[k].read_bytes()==new[k].read_bytes() for k in same if k.startswith('inputs/')}
(A/'basic_review.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k not in ('unittest_native_linux','verifier','manifest')},indent=2))
