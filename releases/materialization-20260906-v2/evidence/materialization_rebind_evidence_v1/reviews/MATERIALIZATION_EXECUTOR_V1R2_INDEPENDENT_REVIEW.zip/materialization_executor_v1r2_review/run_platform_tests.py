import json,sys,unittest,subprocess,os
from pathlib import Path
from unittest.mock import patch
from linux_noreplace_adapter import install
A=Path(__file__).resolve().parent;R=A/'v1r2/materialization_executor_evidence_v1r2'
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True;sys.path.insert(0,str(R));os.chdir(R)
from tests import test_materializer_synthetic as t
from tests import test_executor_evidence as e
blocked={'test_atomic_publish_refuses_late_destination_without_replacement','test_cli_positive_guard_and_synthetic_execution','test_exact_registered_cic_exceptions_are_non_lf_and_succeed','test_full_tree_is_reproducible_across_independent_runs','test_hash_only_replay_has_no_disk_peak_or_replay_files','test_static_expected_outputs_and_metadata'}
def suite(exclude=False):
 out=unittest.TestSuite()
 for c in (t.MaterializerSyntheticTests,e.ExecutorEvidenceVerifierTests):
  for n in unittest.defaultTestLoader.getTestCaseNames(c):
   if exclude and n in blocked:continue
   out.addTest(c(n))
 return out
results={}
with (A/'unittest_platform_independent.log').open('w') as f:
 r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite(True))
results['native_platform_independent']={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),'pass':r.wasSuccessful(),'excluded_six_darwin_dependent':sorted(blocked)}
install(t.materializer)
real_run=subprocess.run
def adapted_run(command,*args,**kwargs):
 if isinstance(command,(list,tuple)) and len(command)>1 and Path(str(command[1])).name=='materialize_dataset_native_v1r2.py':
  command=[command[0],str(A/'cli_linux_adapter.py'),*command[1:]]
 return real_run(command,*args,**kwargs)
with (A/'unittest_linux_syscall_adapter.log').open('w') as f, patch.object(subprocess,'run',adapted_run):
 r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite())
results['linux_syscall_adapter']={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),'pass':r.wasSuccessful(),'NOT_NATIVE_DARWIN_VALIDATION':True,'scope':'review-only FFI adapter delegates Darwin flag 4 to actual Linux renameat2 flag 1. Source/archive/config bytes unchanged.'}
(A/'platform_test_results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
