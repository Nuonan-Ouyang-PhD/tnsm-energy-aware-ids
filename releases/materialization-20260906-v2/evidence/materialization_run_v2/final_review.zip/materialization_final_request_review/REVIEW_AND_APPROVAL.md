# Final materialization request — review decision

## Decision

APPROVED: materialization only, including real-source preflight, deterministic conversion, streaming hash replay, validation and no-overwrite publication. This is not an authorization for splitting, training, encoder fitting, model fitting, source relocation, or deletion.

Approved final-request ZIP SHA-256: `b123293dfe331d59393688d07c799c1fdb42f0df2367ef919c2f949843bff655`.
Archive: `MATERIALIZATION_FINAL_REQUEST_V1.zip`; 321,196 bytes; 8 files (including MANIFEST) and 3 directories. Outer MANIFEST: 7/7; embedded accepted rebind MANIFEST: 18/18.

Approval ID for the external execution record: `MATERIALIZATION-ONLY-20260906-B123293DFE33-AUTHORIZED`.
This document records the assistant project-review decision requested in the conversation. It is not a statement that a machine authorization record has already been written, that real CSV content has been verified, or that the executor has run.

## Exact source scope

ton_iot:
`/Volumes/RESEARCH_DATA/10_PROJECTS/COMPLETE_RESEARCH_BY_SOURCE_PATH/Downloads/tnsm-energy-aware-ids/datasets/incoming/ton_iot`

ciciot2023:
`/Volumes/RESEARCH_DATA/10_PROJECTS/COMPLETE_RESEARCH_BY_SOURCE_PATH/Downloads/tnsm-energy-aware-ids/datasets/extracted/ciciot2023`

n_baiot:
`/Volumes/RESEARCH_DATA/10_PROJECTS/COMPLETE_RESEARCH_BY_SOURCE_PATH/Downloads/tnsm-energy-aware-ids/datasets/extracted/n_baiot`

400 inventoried CSVs; 17,114,499,704 recorded bytes. All 400 recorded relative paths and stat sizes were independently compared with the frozen inventories. This audit did not visit the source directories or read any source CSV.

Expected output: 399 feature/label shard pairs; 54,050,346 accepted rows; native feature dimensions 32 / 39 / 115; exactly three registered CIC truncated final-row exclusions. These are expectations, not measurements of newly generated output.

## Fixed execution bindings

- contract_id: `MATERIALIZATION-EXECUTOR-20260906-V1R2-REBIND1-PROPOSED`
- executor_evidence_zip_sha256: `509074b8e52786118a5b338f8e9f1b86606b999508bd9273465280d01e76223e`
- evidence_archive_root: `materialization_rebind_evidence_v1`
- evidence_manifest_sha256: `db7f28d61e52cd656c7dea2d73a55fd0c35413243c103b2ac44f721b987f33a1`
- contract_sha256: `992790a6953e445cce444b4532d9d45995f5bea4fb9788b3c4b9e910691a0332`
- executor_sha256: `ac9992005047bda7431abccafe8698d5b3b890efbf218605841730a5613b1c2c`
- request_zip_sha256: `55c3c6ee9d6e01fb764a650432b379ca41ca52b703dd33c9ec9cf17088271c63`
- source_metadata_report_sha256: `5fcdc3c7067051be3c79f81f209ebc98df8593882a07a4a852e791faec032443`
- volume_uuid: `FBCBD1E6-330C-452B-AD79-EF7F74B6464B`
- output_root: `/Volumes/RESEARCH_DATA/TNSM-MATERIALIZATION-20260906-V1`
- staging_root: `/Volumes/RESEARCH_DATA/.TNSM-MATERIALIZATION-20260906-V1.staging`

The executor --request-zip remains the original MATERIALIZATION_EXECUTION_REQUEST_V1.zip (SHA-256 55c3c6ee9d6e01fb764a650432b379ca41ca52b703dd33c9ec9cf17088271c63), not this final-request ZIP. --executor-evidence-zip remains MATERIALIZATION_REBIND_EVIDENCE_V1.zip (SHA-256 509074b8e52786118a5b338f8e9f1b86606b999508bd9273465280d01e76223e). Bind this final-request ZIP separately in the external authorization record and append-only DECISIONS entry.

## Execution conditions

Write the external authorization record and append the approval text, exact bindings, source roots and permitted operations to the real DECISIONS.md before execution. Preserve all approved evidence archives and both frozen configurations byte-for-byte; their historical proposed/unauthorized fields are not to be edited to encode this new approval.

Refresh the actual volume UUID and physical backing, writable/unlocked status, free space, source/output nonoverlap, and absence of output/staging immediately before execution. Minimum available space: 26,745,491,380 B; hard output cap: 25,671,749,556 B; retained-space requirement: 1,073,741,824 B. The package observation of 890,136,494,080 B at 2026-09-06T10:17:30.208129Z is evidence of that time only.

Validate all 400 real source identities/hashes/headers/row counts and the exact registered exceptions before staging creation. Only after the complete preflight passes may conversion, streaming replay and validation proceed. This approval covers the whole materialization operation: a successful preflight does not require another approval checkpoint.

Publish only after all contract checks pass, via the reviewed native exclusive-rename path. If any binding, input, space, validation, or path condition fails, stop; preserve and report staging/foreign objects; do not overwrite, broaden exclusions, modify the contract, delete artifacts, or retry automatically.

After success, submit the authorization/provenance, preflight and validation logs, output identity, per-dataset/shard manifests and row/label/byte/hash reconciliation. Do not upload the large full data tree merely for review. Stop after materialization; splitting and training remain unauthorized.

## Review boundaries

The embedded accepted rebind ZIP and review ZIP were byte-compared with the prior local copies and are identical. The inspected package-only rebind verifier was run and passed. The source collection script was read but not executed. Migration log excerpts were checked for selected project/path consistency; original on-machine logs and current CSV content were not independently reread. No production executor, Darwin syscall, source preflight, output creation, or staging creation was performed by this review. Input package files were unchanged after review.

Machine details: audit_results.json; source_400_stat_comparison.json. Raw manifest and embedded-verifier output are included. No full executor test suite or field probe was rerun in this final scope review.
