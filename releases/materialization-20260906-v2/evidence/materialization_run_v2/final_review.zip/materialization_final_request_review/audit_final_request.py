"""Package-only final-request verification. Does not visit real source paths.
No collection script or materialization executor is run by this audit.
"""
from pathlib import Path, PurePosixPath
import collections, hashlib, json, stat, subprocess, sys, os, zipfile
BASE = Path(__file__).resolve().parent
ROOT = BASE / 'input/materialization_final_request_v1'
REBIND = BASE / 'rebind/materialization_rebind_evidence_v1'
ZIP = Path('/mnt/data/MATERIALIZATION_FINAL_REQUEST_V1.zip')
sha = lambda data: hashlib.sha256(data).hexdigest()
file_sha = lambda path: sha(Path(path).read_bytes())
checks = []
def check(name, condition, details=None):
    checks.append({'check':name,'pass':bool(condition),'details':details})
    if not condition: raise AssertionError(name)
def load(path):
    def unique(pairs):
        out={}
        for k,v in pairs:
            if k in out: raise ValueError('duplicate JSON key: '+k)
            out[k]=v
        return out
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=unique)
def snap(root):
    return {p.relative_to(root).as_posix():{'sha256':file_sha(p),'mode':stat.S_IMODE(p.stat().st_mode)} for p in root.rglob('*') if p.is_file()}
def manifest_check(root, label):
    rows=[]; names=[]
    for line in (root/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest,name=line.split('  ',1)
        path=PurePosixPath(name)
        check(label+' manifest safe '+name, not path.is_absolute() and '..' not in path.parts)
        actual=file_sha(root/name); check(label+' SHA '+name, actual==digest)
        rows.append({'path':name,'expected_sha256':digest,'actual_sha256':actual,'pass':True});names.append(name)
    expected=set(snap(root))-{'MANIFEST_SHA256.txt'}
    check(label+' manifest set equality',len(names)==len(set(names)) and set(names)==expected)
    result=subprocess.run(['sha256sum','-c','MANIFEST_SHA256.txt'],cwd=root,text=True,capture_output=True)
    (BASE/(label+'_manifest.log')).write_text(result.stdout+result.stderr)
    check(label+' sha256sum exit 0',result.returncode==0)
    return rows
before={'request':snap(ROOT),'rebind':snap(REBIND)}
check('final ZIP identity',file_sha(ZIP)=='b123293dfe331d59393688d07c799c1fdb42f0df2367ef919c2f949843bff655')
with zipfile.ZipFile(ZIP) as z:
    infos=z.infolist();names=z.namelist()
    check('zip CRC',z.testzip() is None)
    check('no duplicate members',len(names)==len(set(names)))
    for i in infos:
        p=PurePosixPath(i.filename);m=i.external_attr>>16
        check('safe member '+i.filename,not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(m))
        check('permission '+i.filename,stat.S_IMODE(m)==(0o755 if i.is_dir() else 0o644))
        check('no clutter '+i.filename,not any(x in {'__MACOSX','.DS_Store','__pycache__'} or x.startswith('._') for x in p.parts) and p.suffix not in {'.pyc','.pyo'})
    zip_info={'sha256':file_sha(ZIP),'bytes':ZIP.stat().st_size,'entries':len(infos),'files':sum(not i.is_dir() for i in infos),'directories':sum(i.is_dir() for i in infos)}
request_manifest=manifest_check(ROOT,'final_request')
rebind_manifest=manifest_check(REBIND,'embedded_rebind')
check('attached REQUEST.md identical to packaged body',Path('/mnt/data/REQUEST.md').read_bytes()==(ROOT/'REQUEST.md').read_bytes())
req=load(ROOT/'final_request.json');report=load(ROOT/'source_metadata_report.json');migration=load(ROOT/'migration_log_excerpts.json');contract=load(REBIND/'contract/materialization_contract_v1r2.json')
for p in [ROOT/'scripts/prepare_final_source_request.py',REBIND/'scripts/verify_rebind.py']:
    compile(p.read_bytes(),str(p),'exec')  # Syntax only, not executed here.
check('metadata SHA binding',file_sha(ROOT/'source_metadata_report.json')==req['source_metadata_report_sha256'])
for name,previous in [('MATERIALIZATION_REBIND_EVIDENCE_V1.zip','/mnt/data/MATERIALIZATION_REBIND_EVIDENCE_V1(1).zip'),('MATERIALIZATION_REBIND_V1_INDEPENDENT_REVIEW.zip','/mnt/data/MATERIALIZATION_REBIND_V1_INDEPENDENT_REVIEW.zip')]:
    check('embedded unchanged '+name,(ROOT/'evidence'/name).read_bytes()==Path(previous).read_bytes())
check('review ZIP digest',file_sha(ROOT/'evidence/MATERIALIZATION_REBIND_V1_INDEPENDENT_REVIEW.zip')==req['rebind_independent_review']['sha256'])
bindings={'executor_evidence_zip_sha256':ROOT/'evidence/MATERIALIZATION_REBIND_EVIDENCE_V1.zip','evidence_manifest_sha256':REBIND/'MANIFEST_SHA256.txt','contract_sha256':REBIND/'contract/materialization_contract_v1r2.json','executor_sha256':REBIND/'scripts/materialize_dataset_native_v1r2.py'}
for key,p in bindings.items():check('binding '+key,file_sha(p)==req[key])
check('contract ID binding',req['contract_id']==contract['contract_id'])
check('archive root binding',req['evidence_archive_root']==contract['runtime_evidence_binding']['archive_root'])
check('original request SHA binding',req['request_zip_sha256']==contract['baseline_request']['request_zip_sha256'])
original=Path('/mnt/data/MATERIALIZATION_EXECUTION_REQUEST_V1.zip')
if original.exists():check('original request actual ZIP',file_sha(original)==req['request_zip_sha256'])
check('scope map exact',req['proposed_operations_if_separately_approved']==contract['authorization']['required_operations'])
check('unapproved request retained',req['authorized_by_user'] is False and req['authorization_granted'] is False and req['authorization_id'] is None and not any(req['operations_authorized_now'].values()))
for key,ck in [('output_root','root'),('staging_root','staging_root')]:
    check(key+' fixed',req[key]==contract['output_binding'][ck])
for key in ['minimum_free_bytes','hard_output_cap_bytes','scratch_reserve_bytes']:
    check(key+' fixed',req[key]==contract['storage'][key])
check('budget addition',req['minimum_free_bytes']==req['hard_output_cap_bytes']+req['scratch_reserve_bytes'])
volume=report['volume_refresh']
check('volume snapshots identical',req['volume_observation']==volume)
check('recorded UUID',volume['volume_uuid']==req['volume_uuid']=='FBCBD1E6-330C-452B-AD79-EF7F74B6464B')
check('recorded APFS unlocked writable',volume['mount_point']=='/Volumes/RESEARCH_DATA' and volume['filesystem']=='apfs' and volume['writable'] is True and volume['locked'] is False)
check('recorded space sufficient',volume['available_bytes']>=req['minimum_free_bytes'])
check('recorded output/staging absent',volume['formal_paths_absent'] is True)
expected_datasets={'ton_iot','ciciot2023','n_baiot'}
check('three source roots',set(req['source_roots'])==set(report['datasets'])==expected_datasets)
dataset_results={};details=[]
for ds in ['ton_iot','ciciot2023','n_baiot']:
    rec=report['datasets'][ds];invref=contract['input_binding']['inventories'][ds];ip=REBIND/invref['file'];inv=load(ip)
    check(ds+' inventory identity',file_sha(ip)==invref['sha256']==rec['inventory_sha256'])
    entries=inv['files']; bypath={x['relative_path']:x for x in entries}
    check(ds+' unique inventory paths',len(bypath)==len(entries))
    check(ds+' exact observed path set',set(bypath)==set(rec['files']))
    check(ds+' root string binding',rec['source_root']==rec['resolved_path']==req['source_roots'][ds])
    src=PurePosixPath(rec['source_root']);out=PurePosixPath(req['output_root']);staging=PurePosixPath(req['staging_root'])
    check(ds+' absolute and normalized source',src.is_absolute() and '..' not in src.parts and str(src)==rec['source_root'])
    for target in [out,staging]:check(ds+' nonoverlap '+str(target),src!=target and src not in target.parents and target not in src.parents)
    check(ds+' no recorded symlink entries',rec['symlink_entries']==[])
    nbytes=0;nrows=0
    for rel, frozen in bypath.items():
        p=PurePosixPath(rel);obs=rec['files'][rel]
        check(ds+' safe relative '+rel,not p.is_absolute() and '..' not in p.parts)
        check(ds+' stat size '+rel,obs['bytes']==frozen['bytes'])
        check(ds+' device '+rel,obs['device']==volume['source_root_devices'][ds]==volume['output_parent_device'])
        nbytes+=frozen['bytes'];nrows+=frozen['row_count']
        details.append({'dataset':ds,'relative_path':rel,'inventory_bytes':frozen['bytes'],'recorded_stat_bytes':obs['bytes'],'frozen_source_sha256':frozen['sha256'],'content_rehashed_by_this_review':False})
    check(ds+' computed count',len(bypath)==rec['csv_count']==inv['file_count'])
    check(ds+' computed bytes',nbytes==rec['source_bytes']==inv['total_bytes'])
    check(ds+' computed frozen rows',nrows==inv['total_rows'])
    eligible=[x for x in entries if not (ds=='n_baiot' and x['relative_path']=='demonstrate_structure.csv')]
    if ds=='n_baiot':check('structure zero rows',bypath['demonstrate_structure.csv']['row_count']==0)
    dataset_results[ds]={'source_root':rec['source_root'],'csv_count':len(bypath),'recorded_stat_bytes':nbytes,'frozen_rows':nrows,'planned_shard_pairs':len(eligible),'native_features':contract['feature_contract'][ds]['output_columns'],'path_set_match':True,'all_sizes_match':True}
check('TON root layout',set(report['datasets']['ton_iot']['files'])=={'train_test_network.csv'})
check('CIC root is parent of CSV',all(PurePosixPath(p).parts[0]=='CSV' for p in report['datasets']['ciciot2023']['files']))
check('source devices consistent',set(volume['source_root_devices'].values())=={volume['output_parent_device']})
count=sum(v['csv_count'] for v in dataset_results.values());nbytes=sum(v['recorded_stat_bytes'] for v in dataset_results.values());nrows=sum(v['frozen_rows'] for v in dataset_results.values());shards=sum(v['planned_shard_pairs'] for v in dataset_results.values())
check('400 total',count==report['total_csv_count']==req['expected_inventoried_files']==400)
check('total bytes',nbytes==report['total_bytes']==contract['storage']['source_bytes']==17114499704)
check('399 pairs',shards==req['expected_output_shards']==contract['expected_real_output']['feature_shards']==contract['expected_real_output']['label_shards']==399)
check('frozen source/retained rows',nrows==contract['expected_real_output']['source_rows']==54050349 and nrows-req['registered_excluded_rows']==req['expected_output_rows']==contract['expected_real_output']['materialized_rows']==54050346 and req['registered_excluded_rows']==3)
for ds,v in dataset_results.items():
    expected=contract['expected_real_output']['per_dataset'][ds];check(ds+' expected retained',v['frozen_rows']-(3 if ds=='ciciot2023' else 0)==expected['rows']);v['expected_retained_rows']=expected['rows']
entrance=report['original_project_entrance'];dest=str(PurePosixPath(req['source_roots']['ton_iot']).parents[2])
check('original symlink targets selected project',entrance['symlink_target']==dest)
statuses=[]
for name,data in migration.items():
    record=data['selected_project_record'];check(name+' selected source/destination',record['source']==entrance['path'] and record['destination']==dest)
    check(name+' external-log hash declared',len(data['existing_log_sha256'])==64)
    statuses.append(record['status'])
check('migration excerpt statuses',set(statuses)=={'PASS','MOVED_VERIFIED_ORIGINAL_PATH_LINKED'})
# Re-run only the already inspected package-only verifier, never the field collector.
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
result=subprocess.run([sys.executable,'-B',str(REBIND/'scripts/verify_rebind.py'),'--root',str(REBIND),'--zip',str(ROOT/'evidence/MATERIALIZATION_REBIND_EVIDENCE_V1.zip')],capture_output=True,text=True,env=env,timeout=30)
(BASE/'embedded_rebind_verifier.log').write_text(result.stdout+result.stderr)
check('embedded package verifier exit 0',result.returncode==0)
verified=json.loads(result.stdout);check('embedded verifier PASS',verified['status']=='PASS')
check('review inputs unchanged',before=={'request':snap(ROOT),'rebind':snap(REBIND)})
audit={'scope':'package bytes and recorded metadata only; no Mac connection, real CSV access, source scan, original migration-log reread, or materialization', 'decision':'APPROVE_MATERIALIZATION_ONLY_SUBJECT_TO_MANDATORY_EXECUTION_PREFLIGHT','zip':zip_info,'manifest':request_manifest,'embedded_manifest':rebind_manifest,'bindings':{k:file_sha(p) for k,p in bindings.items()},'original_request_zip_sha256':req['request_zip_sha256'],'source_metadata_report_sha256':req['source_metadata_report_sha256'],'metadata_observed_at_utc':report['observed_at_utc'],'datasets':dataset_results,'totals':{'csv_files':count,'recorded_stat_bytes':nbytes,'frozen_source_rows':nrows,'expected_output_rows':req['expected_output_rows'],'shard_pairs':shards,'registered_exclusions':3},'recorded_volume':volume,'headroom_above_required_bytes':volume['available_bytes']-req['minimum_free_bytes'],'source_migration_evidence_status':'selected existing-log excerpts only; original logs not independently reread; content verification reserved for execution preflight','embedded_verifier_result':verified,'checks_passed':len(checks),'checks':checks,'inputs_unchanged':True,'execution_performed_by_reviewer':False}
(BASE/'audit_results.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
(BASE/'source_400_stat_comparison.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'decision':audit['decision'],'zip':zip_info,'manifest':len(request_manifest),'embedded_manifest':len(rebind_manifest),'checks_passed':len(checks),'datasets':dataset_results,'recorded_available':volume['available_bytes'],'headroom':audit['headroom_above_required_bytes'],'no_input_modifications':True},ensure_ascii=False,indent=2))
