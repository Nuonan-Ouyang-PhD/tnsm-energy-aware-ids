"""Read-only archive/rebind audit. Never probes a live volume or opens raw CSVs."""
import collections
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo

A = Path('/mnt/data/materialization_rebind_independent_audit')
R = A / 'input/materialization_rebind_evidence_v1'
sha = lambda b: hashlib.sha256(b).hexdigest()

def strict_pairs(items):
    d = {}
    for k, v in items:
        if k in d:
            raise ValueError('duplicate JSON key: '+k)
        d[k] = v
    return d

def load(b):
    return json.loads(b, object_pairs_hook=strict_pairs)

def changes(a,b,path=''):
    out=[]
    if type(a) is not type(b):
        return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):
        if set(a)!=set(b):
            for k in sorted(set(a)^set(b)):
                out.append({'path':path+'/'+k,'kind':'added' if k not in a else 'removed'})
        for k in sorted(set(a)&set(b)):
            out+=changes(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        if len(a)!=len(b):
            return [{'path':path,'before':a,'after':b}]
        for i,(x,y) in enumerate(zip(a,b)):
            out+=changes(x,y,path+'/'+str(i))
    elif a!=b:
        out.append({'path':path,'before':a,'after':b})
    return out

baseline=Path('/mnt/data/MATERIALIZATION_EXECUTOR_EVIDENCE_V1R2.zip')
review=Path('/mnt/data/MATERIALIZATION_EXECUTOR_V1R2_INDEPENDENT_REVIEW.zip')
assert baseline.read_bytes()==(R/'baseline'/baseline.name).read_bytes()
assert review.read_bytes()==(R/'reviews'/review.name).read_bytes()
basezip=zipfile.ZipFile(baseline)
prefix='materialization_executor_evidence_v1r2/'
CP='contract/materialization_contract_v1r2.json'
EP='scripts/materialize_dataset_native_v1r2.py'
b=load(basezip.read(prefix+CP)); c=load((R/CP).read_bytes())
diff=changes(b,c)
assert len(diff)==7
assert diff==load((R/'reports/contract_semantic_diff.json').read_bytes())
allowed={'/contract_id','/output_binding/binding_status','/output_binding/new_disk_note','/output_binding/root','/output_binding/staging_root','/runtime_evidence_binding/archive_root','/storage/current_location_observation_passes'}
assert {x['path'] for x in diff}==allowed
unchanged={}
for rel in b['runtime_evidence_binding']['required_local_files']:
    if rel!=CP:
        data=(R/rel).read_bytes()
        assert data==basezip.read(prefix+rel), rel
        unchanged[rel]=sha(data)
assert len(unchanged)==9

# Use the independently available #24 archive, not solely the nested baseline.
f24=zipfile.ZipFile('/mnt/data/FEATURE_PROTOCOL_FREEZE_EVIDENCE_V1.zip')
config_crosscheck={}
for name in ['feature_policy.json','label_ontology.json']:
    members=[n for n in f24.namelist() if n.endswith('/config/'+name)]
    assert len(members)==1, members
    blob=(R/'inputs/protocol'/name).read_bytes()
    assert blob==f24.read(members[0])
    config_crosscheck[name]=sha(blob)

# Strict JSON parsing and independent MANIFEST coverage.
json_count=0
for p in R.rglob('*.json'):
    load(p.read_bytes());json_count+=1
manifest={}
for line in (R/'MANIFEST_SHA256.txt').read_text().splitlines():
    digest,path=line.split('  ',1)
    assert path not in manifest and len(digest)==64
    assert not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts
    assert sha((R/path).read_bytes())==digest
    manifest[path]=digest
content={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}-{'MANIFEST_SHA256.txt'}
assert set(manifest)==content and len(manifest)==18

# Audit captured observations and their relationships, not the live Mac volume.
p=load((R/'reports/native_volume_probe.json').read_bytes())
q=load((R/'rebind_request.json').read_bytes())
assert p['executor_sha256']==sha((R/EP).read_bytes())==q['executor_sha256']
assert q['probe_report_sha256']==sha((R/'reports/native_volume_probe.json').read_bytes())
assert q['contract_sha256']==sha((R/CP).read_bytes())
for timing in ('before','after'):
    o=p[timing];v=o['volume']
    assert v['VolumeUUID']==q['volume_uuid']==v['DiskUUID']
    assert v['MountPoint']==q['mount_point']==str(Path(q['output_root']).parent)==str(Path(q['staging_root']).parent)
    assert v['FilesystemType']==q['filesystem']=='apfs'
    assert v['Encryption'] is True and v['Writable'] is True
    assert v['Locked'] is False and v['Internal'] is False
    assert v['DeviceIdentifier']==q['volume_device']
    assert [s['DeviceIdentifier'] for s in o['physical_stores']]==[s['APFSPhysicalStore'] for s in v['APFSPhysicalStores']]
    assert [s['ParentWholeDisk'] for s in o['physical_stores']]==q['physical_devices']
    assert [d['DeviceIdentifier'] for d in o['physical_devices']]==q['physical_devices']
    assert all(d['Internal'] is False and d['VirtualOrPhysical']=='Physical' for d in o['physical_devices'])
    assert (o['parent_device'],o['parent_inode'])==(q['parent_device'],q['parent_inode'])
    assert o['statvfs_available_bytes']>=c['storage']['minimum_free_bytes']
assert q['available_bytes_observed']==p['after']['statvfs_available_bytes']
assert q['observed_at_utc']==p['after']['observed_at_utc']
assert q['volume_capacity_bytes']==p['after']['volume']['APFSContainerSize']
assert q['minimum_free_bytes']==c['storage']['minimum_free_bytes']
assert q['output_hard_cap_bytes']==c['storage']['hard_output_cap_bytes']
assert q['authorization_granted'] is False and c['authorization']['granted'] is False
assert q['authorized_operations_now']=={'materialization':False,'splitting':False,'training':False}
assert p['real_csv_access'] is False and p['formal_output_or_staging_created'] is False
assert q['output_and_staging_absent_at_preparation'] is True

cases=[]
for x in p['cases']:
    assert x['pass'] is True
    if x['case']=='absent':
        assert x['rejection'] is None
        assert '.candidate.staging' not in x['after']['children']
        assert x['before']['children']['.candidate.staging']==x['after']['children']['candidate']
    else:
        assert x['rejection'] and x['before']==x['after']
    cases.append({k:x[k] for k in ('case','syscall_mode','pass','rejection')})
assert sum(x['syscall_mode']=='native Darwin renameatx_np RENAME_EXCL' for x in cases)==5
assert sum(x['syscall_mode']!='native Darwin renameatx_np RENAME_EXCL' for x in cases)==2

def leaves(node):
    if 'children' in node:
        for ch in node['children'].values():
            yield from leaves(ch)
    elif stat.S_ISREG(node['mode']):
        yield node
leaf_nodes=[node for x in p['cases'] for node in leaves(x['after'])]
assert len(leaf_nodes)==p['retained_regular_files']==11
assert sum(x['bytes'] for x in leaf_nodes)==p['retained_logical_bytes']==370

inventories={}
for path in sorted((R/'inputs/inventories').glob('*.json')):
    inv=load(path.read_bytes()); files=inv['files']
    assert len(files)==inv['file_count']
    assert sum(x['bytes'] for x in files)==inv['total_bytes']
    assert sum(x['row_count'] for x in files)==inv['total_rows']
    inventories[inv['dataset_id']]={
        'inventory_file':str(path.relative_to(R)), 'inventory_sha256':sha(path.read_bytes()),
        'csv_files':inv['file_count'],'bytes':inv['total_bytes'],'raw_rows':inv['total_rows'],
        'sample_relative_path':files[0]['relative_path'],
        'top_level_components': sorted({PurePosixPath(x['relative_path']).parts[0] for x in files}),
        'actual_source_root':None,'migration_status':'not_supplied_in_rebind_package',
        'verification_scope':'inventory metadata only; no raw CSV accessed or hashed'
    }
assert sum(x['csv_files'] for x in inventories.values())==400
assert sum(x['bytes'] for x in inventories.values())==c['storage']['source_bytes']==17114499704

# Test only the CLI's missing-authorization refusal: no real source root supplied.
cmd=[sys.executable,'-B',str(R/EP),'--contract',str(R/CP),'--execute']
run=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=15,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
(A/'unauthorized_cli.log').write_text(run.stdout+run.stderr)
assert run.returncode==2 and 'complete authorization evidence is required before source access' in run.stderr

state0=load((A/'archive_audit.json').read_bytes())['input_file_snapshot']
state1={str(f.relative_to(R)):{'sha256':sha(f.read_bytes()),'mode':oct(stat.S_IMODE(f.stat().st_mode))} for f in sorted(R.rglob('*')) if f.is_file()}
assert state1==state0
now_obs=datetime.fromisoformat(q['observed_at_utc']).astimezone(ZoneInfo('Australia/Melbourne')).isoformat()
report={
  'verdict':'PASS for output-only rebind evidence; operational authorization remains withheld',
  'reviewed_zip_sha256':sha(Path('/mnt/data/MATERIALIZATION_REBIND_EVIDENCE_V1(1).zip').read_bytes()),
  'manifest_sha256':sha((R/'MANIFEST_SHA256.txt').read_bytes()),'manifest_files':len(manifest),
  'strict_json_files_parsed':json_count,
  'baseline_zip_byte_equal_to_previously_uploaded_baseline':True,
  'accepted_review_zip_byte_equal_to_previously_generated_review':True,
  'contract_diff':diff, 'unchanged_runtime_files':unchanged,
  'frozen_config_crosscheck_with_actual_24_archive':config_crosscheck,
  'volume_observation_time_melbourne':now_obs,
  'volume_report_identity':{k:q[k] for k in ('volume_uuid','mount_point','filesystem','encryption','writable','physical_devices','volume_device','volume_capacity_bytes','available_bytes_observed','minimum_free_bytes','output_hard_cap_bytes')},
  'observed_free_bytes_above_minimum':q['available_bytes_observed']-q['minimum_free_bytes'],
  'observed_free_gib':q['available_bytes_observed']/2**30,
  'native_probe_evidence_cases':cases,
  'retained_probe_regular_files':len(leaf_nodes),'retained_probe_logical_bytes':sum(x['bytes'] for x in leaf_nodes),
  'source_inventory_metadata':inventories,
  'actual_source_binding_complete':False,
  'unauthorized_cli_exit':run.returncode,
  'input_contents_and_permissions_unchanged':True,
  'authorization_granted':False,'operations':q['authorized_operations_now'],
  'limitations':[
    'Reviewed recorded Darwin results; no native Darwin probe was run in this Linux review environment.',
    'No direct access to the user Mac, volume, current capacity, Git object store or source CSVs.',
    'Formal output/staging absence is a supplied preparation observation, not independently refreshed here.',
    'Source root paths and migration states are not present; frozen hashes alone do not identify their current filesystem location.',
    'No repetition of the previously accepted 37-test executor suite or 187-check implementation validation is claimed.'
  ]
}
(A/'semantic_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(A/'contract_diff_independent.json').write_text(json.dumps(diff,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('unchanged_runtime_files','contract_diff','source_inventory_metadata','native_probe_evidence_cases')},ensure_ascii=False,indent=2))
print('SOURCE ROOT SHAPES',json.dumps(inventories,ensure_ascii=False,indent=2))
