# Git provenance

No Git object was required for recovery. The exact historical bytes were recovered from saved runtime directories. Git/worktree provenance remains a separate limitation and is not inferred from this archive.
