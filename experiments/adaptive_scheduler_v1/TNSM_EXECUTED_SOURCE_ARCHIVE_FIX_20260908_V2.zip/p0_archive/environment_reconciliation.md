# Environment reconciliation

Recovery was performed by read-only hash search over saved Codex runtime directories and the project workspace. The matching files came from `TNSM-adaptive-runtime-v1/physical-r2` and `physical-r3`; the copies are identical. No V1 package, source CSV, frozen configuration, or primary result was changed.
