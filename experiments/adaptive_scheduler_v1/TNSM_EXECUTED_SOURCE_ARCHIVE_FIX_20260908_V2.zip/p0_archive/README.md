# P0 exact executed-source archival recovery

All six hashes listed by the independent audit were recovered byte-for-byte from saved immutable runtime directories. No source file was edited and the original V1 runtime manifest was not rewritten.

The exact copies are retained under `executed_source/`. The later currently packaged source is retained separately under `supplied_later_source/`.
